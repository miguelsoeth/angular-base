export interface QueryHistoryResponse {
    username: string
    type: string
    document: string
    referredDate: string
    interval: string
}
  